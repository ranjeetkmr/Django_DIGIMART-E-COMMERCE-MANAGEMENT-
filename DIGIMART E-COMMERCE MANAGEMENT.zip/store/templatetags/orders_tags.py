from django import template


register = template.Library()

@register.simple_tag
def get_order_status_class(status):
    if status == "COMPLETED": 
        return "Success"
    elif status=="PENDING":
        return 'Warning'
    else:
        return 'info'
