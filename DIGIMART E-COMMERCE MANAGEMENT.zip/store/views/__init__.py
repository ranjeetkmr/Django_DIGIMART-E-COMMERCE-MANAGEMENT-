from store.views.home import home
from store.views.about import about
from store.views.cart import cart,add_to_cart
from store.views.checkout import checkout
from store.views.orders import OrderListView
from store.views.authentication import LoginView, signup, signout
from store.views.product import ProductDetailView
from store.views.payment import validatePayment
from store.views.search import search
