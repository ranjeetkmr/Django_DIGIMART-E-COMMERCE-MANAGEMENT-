from django.shortcuts import render
from store.models import Product


def search(request):
    query = request.GET [ 'query' ]
    Products = Product.objects.filter(title_icontains=query)
    params = {'Products': Products}
    return render(request, 'search.html', params)
