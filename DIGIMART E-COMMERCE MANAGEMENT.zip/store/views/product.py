from store.models import Product
from django.shortcuts import render
from math import floor
from django.views.generic.detail import DetailView




class ProductDetailView(DetailView):
    template_name = 'product_details.html'
    model = Product
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        product = context.get('product')
        request = self.request
        size = request.GET.get('size')
        if size is None:
            size = product.sizevariant_set.all().order_by('price').first()
        else:
            size = product.sizevariant_set.get(size=size)

        size_price = floor(product.price)

        sell_price = size_price - (size_price * (product.discount / 100))
        sell_price = floor(sell_price)

        context = {
            'product': product,
            'price': size_price,
            'sell_price': sell_price,
            'active_size': size
        }
        return context



