from django.shortcuts import render, HttpResponse, redirect
from store.models.about import About


def about(request):
    abouts = About.objects.all()
    context = {'abouts': abouts}
    return render(request, 'about.html', context= context)


