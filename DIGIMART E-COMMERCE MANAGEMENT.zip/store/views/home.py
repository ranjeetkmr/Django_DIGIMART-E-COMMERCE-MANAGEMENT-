from store.models import Product, SizeVariant, Cart, Order, OrderItem, Payment,\
    Occasion, Brand, Color, IdealFor, NeckType, Sleeve
from django.shortcuts import render, HttpResponse, redirect
from django.core.paginator import Paginator
from urllib.parse import urlencode
# Create your views here.
from store.models.product_properties import Category


def home(request):
    query = request.GET
    products = []
    products = Product.objects.all()
    category = query.get('category')
    brand = query.get('brand')
    neckType = query.get('necktype')
    color = query.get('color')
    idealFor = query.get('idealfor')
    sleeve = query.get('sleeve')
    page = query.get('page')

    if page is None or page == '':
        page = 1
    if category != '' and category is not None:
        products = products.filter(brand__slug=category)
    if brand != '' and brand is not None:
        products = products.filter(brand__slug=brand)
    if neckType != '' and neckType is not None:
        products = products.filter(neck_type__slug=neckType)
    if color != '' and color is not None:
        products = products.filter(color__slug=color)
    if sleeve != '' and sleeve is not None:
        products = products.filter(sleeve__slug=sleeve)
    if idealFor != '' and idealFor is not None:
        products = products.filter(ideal_for__slug=idealFor)

    occasions = Occasion.objects.all()
    brands = Brand.objects.all()
    sleeves = Sleeve.objects.all()
    idealFor = IdealFor.objects.all()
    neckTypes = NeckType.objects.all()
    colors = Color.objects.all()
    category = Category.objects.all()

    cart=request.session.get('cart')

    paginator = Paginator(products, 4)
    page_object = paginator.get_page(page)

    query = request.GET.copy()
    query [ 'page' ] = ''
    pageurl = urlencode(query)

    context = {
        "page_object": page_object,
        "products": products,
        "occasions": occasions,
        "category":category,
        "brands": brands,
        'colors': colors,
        'sleeves': sleeves,
        'neckTypes': neckTypes,
        'idealFor': idealFor,
        'pageurl': pageurl
    }
    return render(request, template_name='home.html', context=context)
