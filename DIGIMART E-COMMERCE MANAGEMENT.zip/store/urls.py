import views
from django.contrib.auth.decorators import login_required
from django.conf.urls.static import static
from DIGIMART import settings
from django.urls import path
from store.views import home, about, cart, checkout, add_to_cart
from store.views.orders import OrderListView
from store.views.authentication import LoginView, signup, signout
from store.views.product import ProductDetailView
from store.views.payment import validatePayment
from store.views.search import search


urlpatterns = [
   path('', home, name='homepage'),
   path('about/', about, name='about'),
   path('cart/', cart),
   path('checkout', checkout),
   path('orders/', login_required(OrderListView.as_view(),login_url='login'), name='orders'),
   path('login', LoginView.as_view() , name='login'),
   path('signup/', signup),
   path('search/', search),
   path('logout/', signout),
   path('product/<str:slug>', ProductDetailView.as_view()),
   path('validate_payment', validatePayment),
   path('addtocart/<str:slug>/<str:size>', add_to_cart)
   ]

urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)




