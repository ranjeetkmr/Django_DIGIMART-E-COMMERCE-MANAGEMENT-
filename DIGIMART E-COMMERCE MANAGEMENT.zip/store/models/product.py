from django.db import models
from store.models.product_properties import Brand, Color, Occasion, IdealFor, NeckType, Sleeve

CATEGORY_CHOICES = (
    ('M', 'Mobile'),
    ('L', 'Laptop'),
    ('T', 'Toys'),
    ('TW', 'Top Wear'),
    ('S', 'Shoes'),
    ('BW', 'Bottom Wear'),
)


class Product(models.Model):
    objects = None
    name = models.CharField(max_length=50, null=False)
    slug = models.CharField(max_length=200, null=True, unique=True, default="")
    description = models.TextField(max_length=500, null=True)
    discount = models.IntegerField(default=0)
    price = models.IntegerField(default=0)
    image = models.ImageField(upload_to='upload/images/', null=False)
    occasion = models.ForeignKey(Occasion, on_delete=models.CASCADE, blank=True, null=True)
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE)
    category = models.CharField(choices=CATEGORY_CHOICES, max_length=2, default=1)
    sleeve = models.ForeignKey(Sleeve, on_delete=models.CASCADE, null=True, blank=True)
    neck_type = models.ForeignKey(NeckType, on_delete=models.CASCADE, null=True, blank=True)
    ideal_for = models.ForeignKey(IdealFor, on_delete=models.CASCADE, null=True, blank=True)
    color = models.ForeignKey(Color, on_delete=models.CASCADE)


def __str__(self):
    return self.name
