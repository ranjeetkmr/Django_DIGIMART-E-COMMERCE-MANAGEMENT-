from django.db import models


class ProductProperty(models.Model):
    title = models.CharField(max_length=30, null=False)
    slug = models.CharField(max_length=30, null=False, unique=True)

    def __str__(self):
        return self.title

    class Meta:
        abstract = True


class Category(ProductProperty):
    pass


class Occasion(ProductProperty):
    pass


class IdealFor(ProductProperty):
    pass


class NeckType(ProductProperty):
    pass


class Sleeve(ProductProperty):
    pass


class Brand(ProductProperty):
    pass


class Color(ProductProperty):
    pass
