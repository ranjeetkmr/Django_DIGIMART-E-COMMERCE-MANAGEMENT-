from django.db import models


class About(models.Model):
    objects = None
    image = models.ImageField(upload_to='upload/images/', null=False)
    description = models.TextField(max_length=500, null=True, default=1)

    @classmethod
    def get_all_abouts(cls):
        pass
