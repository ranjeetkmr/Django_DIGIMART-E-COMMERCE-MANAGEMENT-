from django.db import models
from store.models.product import Product


class SizeVariant(models.Model):
    SIZES = (
        ('0-6 Months', "0-6 Months"),
        ('6-12 Months', "6-12 Months"),
        ('1-3 years', "1-3 years"),
        ('5-6 years', "5-6 years"),
        ('7-8 years', "7-8 years"),
        ('8-10 years', "8-10 years"),
        ('10-12 years', "10-12 years"),
        ('26', "26"),
        ('28', "28"),
        ('30', "30"),
        ('32', "32"),
        ('5', "5"),
        ('6', "6"),
        ('7', "7"),
        ('8', "8"),
        ('Laptop', "Laptop"),
        ('Mobile', "Mobile"),
        ('S', "Small"),
        ('M', "Medium"),
        ('L', "Large"),
        ('XL', "Extra Large"),
        ('XXL', "Extra Extra Large"),
    )
    price = models.IntegerField(null=False)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    size = models.CharField(choices=SIZES, max_length=20,blank=True,null=True)

    def __str__(self):
        return f'{self.size}'
